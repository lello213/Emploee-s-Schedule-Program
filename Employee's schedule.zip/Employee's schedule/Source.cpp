#include <fstream>
#include <iostream>
using namespace std;
// My program reads the input.txt file and based on the appointments of each employee builds the attendee list in the output.txt
int id = 0; // id that will be incremented and assigned for each new Employee

struct Time {
    int Day, Hour, Minute, Second;
};

struct Attendee;

struct Appointment {
    string Title;
    Time StartingTime;
    int Duration;
    Attendee* ListOfAttendees;
    Appointment* next;
};

struct Employee {
    int UniqueID;
    string FirstName, LastName, EmailAddress;
    Appointment* Calendar;
    Employee* next;
    Employee* previous;
};

struct Attendee {
    Employee* self;
    Attendee* next;
};

struct Company {
    Employee* Head, * Tail;
};

void displayCompany(Company comp) {  // Display List of Employees with corresponding Appointments
    if (comp.Head == NULL) {
        cout << "The company list is empty" << endl;
        return;
    }
    for (Employee* curr = comp.Head; curr != NULL; curr = curr->next) {
        cout << "EMPLOYEE # " << curr->UniqueID << endl;
        cout << "-------------" << endl;
        cout << curr->FirstName << " | " << curr->LastName << " | " << curr->EmailAddress << " | " << "APPOINTMENTS: " << endl;
        for (Appointment* app = curr->Calendar; app != NULL; app = app->next) {
            cout << "-" << app->Title << " | " << app->StartingTime.Day << " | " << app->StartingTime.Hour << " | " << app->StartingTime.Minute << " | " << app->StartingTime.Second << " | " << app->Duration << " | " << "ATTENDEES: " << " | ";
            for (Attendee* att = app->ListOfAttendees; att != NULL; att = att->next) {
                cout << att->self->UniqueID << "-" << att->self->FirstName << " " << att->self->LastName << " | ";
            }
            cout << endl;
        }
        cout << endl << endl;
    }
    cout << endl;
}

void printEmpInfo(Company comp, int id, string fname, string lname, string email) {  // Display All Employee info that matches the given id 
    for (Employee* e = comp.Head; e != NULL; e = e->next) {
        if (e->UniqueID == id) {
            cout << "Appointment:" << endl;
            for (Appointment* app = e->Calendar; app != NULL; app = app->next) {
                cout << "-" << app->Title << " at " << app->StartingTime.Day << ":" << app->StartingTime.Hour << ":" << app->StartingTime.Minute << ":" << app->StartingTime.Second << " with a duration of " << app->Duration << " | " << "Appointment Attendees: ";
                for (Attendee* att = app->ListOfAttendees; att != NULL; att = att->next) {
                    cout << att->self->UniqueID << "-" << att->self->FirstName << " " << att->self->LastName << " | ";
                }
                cout << endl;
            }
        }
    }
}

bool isEmpty(Company comp) {  // Checks if the Company doesn't have any Employee in it
    return (comp.Head == NULL);
}

Employee* FindEmployee(Company comp, int ID, string firstname, string lastname, string email) { // Searches for a specific Employee 
    for (Employee* curr = comp.Head; curr != NULL; curr = curr->next) {
        if ((curr->UniqueID == ID) && (curr->FirstName == firstname) && (curr->LastName == lastname) && (curr->EmailAddress == email)) {
            return curr;
        }
    }
    return NULL;
}

Attendee* FindTitleAttendee(Company comp, int Id, string title, int day, int hour, int min, int sec, int duration,Attendee* att) {  // Searches for an Employee who has an appointment title equal to title given as parameter along with other appointments parameters
    Attendee* at=att;
    Attendee* t;

    for (Employee* curr = comp.Head; curr != NULL; curr = curr->next) {
        for (Appointment* app = curr->Calendar; app != NULL; app = app->next) {
            if ((curr->UniqueID != Id) && (app->Title == title) && (app->StartingTime.Day == day) && (app->StartingTime.Hour == hour) && (app->StartingTime.Minute == min) && (app->StartingTime.Second == sec) && (app->Duration = duration)) {
                t = new Attendee;
                t->self = curr;
                at->next = t;
                at = at->next;
                at->next = NULL;
            }
            else
                at->next = NULL;
        }
    }
    return at;
}

Employee* FindCalendarDay(Company comp, int day) {   // Searches for the appointment's day that are before a given day
    for (Employee* e = comp.Head; e != NULL; e = e->next) {
        for (Appointment* a = e->Calendar; a != NULL; a = a->next) {
            if (a->StartingTime.Day < day)
                return e;
        }
    }
    return NULL;
}

Employee* FindbyID(Company comp, int Id) {  // Searches for an Employee given an Id only
    for (Employee* curr = comp.Head; curr != NULL; curr = curr->next) {
        if ((curr->UniqueID == Id)) {
            return curr;
        }
    }
    return NULL;
}

Company insertSorted(Company comp, int ID, string firstname, string lastname, string email, string title, int day, int hour, int minute, int second, int duration)  // Inserts the Employees in the Company in an ascending order depending on their Unique ID
{
    Employee* curr, * prev;
    for (prev = NULL, curr = comp.Head; curr != NULL; prev = curr, curr = curr->next) {
        if (curr->UniqueID > ID) {
            break;
        }
    }

    Employee* Emp = new Employee; // declaration of new structure variables since we are assigning new addresses to the doubly linked list Company
    Appointment* app = new Appointment; // Each new Employee has a new Appointment
    Attendee* att = new Attendee;  // Each new Appointment has an attendee
    Appointment* acurr, * aprev;
    Employee* ecurr;
    app->next = NULL;
    Emp->Calendar = app; // assigning a new address to the new Employee's Appointment 
    Emp->Calendar->ListOfAttendees = att; // assigning a new address to the new Appointment's Attendee
    Emp->UniqueID = ID;
    Emp->FirstName = firstname;
    Emp->LastName = lastname;
    Emp->EmailAddress = email;

    Emp->Calendar->Title = title;
    Emp->Calendar->StartingTime.Day = day;
    Emp->Calendar->StartingTime.Hour = hour;
    Emp->Calendar->StartingTime.Minute = minute;
    Emp->Calendar->StartingTime.Second = second;
    Emp->Calendar->Duration = duration;

    Emp->Calendar->ListOfAttendees->self = Emp; // Since the Employee is part of the Appointment he's also an attendee
    Emp->Calendar->ListOfAttendees->next = NULL;

    for (Employee* e1 = comp.Head; e1 != NULL; e1 = e1->next) { // Searches if the Employee is already present in the Company so there is no need to insert him/her as new Employee, we just assign a new Appointment
        if (e1->UniqueID == ID) {
            for (acurr = e1->Calendar, aprev = NULL; acurr != NULL; aprev = acurr, acurr = acurr->next) {} // searches the last Appointment the Employee has
            if (aprev == NULL) { // if no Appointment was given previously to the Employee
                acurr = Emp->Calendar;
                return comp;
            }
            aprev->next = Emp->Calendar; // add the new Appointment to the other Appointments
            return comp;
        }
    }

    id++; // increment id since a new Employee is entered

    if (prev == NULL) {  // if one only Employee is present in the Company 
        Emp->next = comp.Head;
        comp.Head->previous = Emp;
        comp.Head = Emp;
        return comp;
    }

    prev->next = Emp;
    Emp->next = curr;
    Emp->previous = prev;
    return comp;
}

Company insertEmployee(Company comp, int ID, string firstname, string lastname, string email)  // to insert a new employee to the linked list without any appointment
{
    Employee* curr, * prev;
    for (prev = NULL, curr = comp.Head; curr != NULL; prev = curr, curr = curr->next) {
        if (curr->UniqueID > ID) {
            break;
        }
    }

    Employee* Emp = new Employee;
    Employee* ecurr;
    Emp->Calendar = NULL;
    Emp->UniqueID = ID;
    Emp->FirstName = firstname;
    Emp->LastName = lastname;
    Emp->EmailAddress = email;

    if (prev == NULL) {
        Emp->next = comp.Head;
        comp.Head->previous = Emp;
        comp.Head = Emp;
        return comp;
    }

    prev->next = Emp;
    Emp->next = curr;
    Emp->previous = prev;
    return comp;
}

Company createList(Company comp) { // Creates List of Attendees
    Attendee* acurr;
    for (Employee* e1 = comp.Head; e1 != NULL; e1 = e1->next) {
        for (Appointment* a1 = e1->Calendar; a1 != NULL; a1 = a1->next) {
            for (acurr = a1->ListOfAttendees; acurr->next != NULL; acurr = acurr->next) {} // searches for the last Employee in the Attendee List
            FindTitleAttendee(comp, a1->ListOfAttendees->self->UniqueID, a1->Title, a1->StartingTime.Day, a1->StartingTime.Hour, a1->StartingTime.Minute, a1->StartingTime.Second, a1->Duration, acurr); // find employee in company with same appointment title but different id 

            }
        }
    
    return comp;
}

Company deleteList(Company comp, int Id) { // Delete a specific attendee in the List of Attendees
    Attendee* prev, * curr;
    Attendee* tmp;
    for (Employee* e = comp.Head; e != NULL; e = e->next) {
        for (Appointment* a = e->Calendar; a != NULL; a = a->next) {
            for (curr = a->ListOfAttendees, prev = NULL; curr != NULL; prev = curr, curr = curr->next) {
                if (curr->self->UniqueID == Id && prev == NULL) {
                    tmp = curr->next;
                    delete curr;
                    curr = tmp;
                    break;
                }
                else  if (curr->self->UniqueID == Id && prev!=NULL && curr->next == NULL) {
                    prev->next = NULL;
                    delete curr;
                    curr = NULL;
                    break;
                }
                else if (curr->self->UniqueID == Id) {
                    prev->next = curr->next;
                    delete curr;
                    curr = prev->next;
                }
            }
        }
    }
    return comp;
}

Company deleteEmployee(Company comp, int ID) {  // deletes specific Employee according to a given ID
    Employee* curr;
    for (curr = comp.Head; curr != NULL; curr = curr->next) {
        if ((curr->UniqueID == ID)) {
            break;
        }
    }

    if (curr == NULL) // if the company has no Employees in it
        return comp;

    if ((curr->next == NULL) && (curr->previous == NULL)) { // if there is only one Employee in the company
        cout << "The Employee " << comp.Head->FirstName << " " << comp.Head->LastName << " with the ID " << comp.Head->UniqueID << " has been deleted!" << endl;
        deleteList(comp, ID); // deletes the Employee present in the appointment's list of attendee
        delete comp.Head;
        comp.Head = NULL;
        comp.Tail = NULL;
        return comp;
    }

    if (curr->previous == NULL) { // if the Employee to be deleted is the first Employee in the Company
        Employee* after = comp.Head->next;
        cout << "The Employee " << comp.Head->FirstName << " " << comp.Head->LastName << " with the ID " << comp.Head->UniqueID << " has been deleted!" << endl;
        deleteList(comp, ID); // deletes the Employee present in the appointment's list of attendee
        delete comp.Head;
        after->previous = NULL;
        comp.Head = after;
        return comp;
    }

    if (curr->next == NULL) { // if the Employee to be deleted is the last Employee in the Company
        Employee* before = comp.Tail->previous;
        cout << "The Employee " << comp.Tail->FirstName << " " << comp.Tail->LastName << " with the ID " << comp.Tail->UniqueID << " has been deleted!" << endl;
        deleteList(comp, ID); // deletes the Employee present in the appointment's list of attendee
        delete comp.Tail;
        before->next = NULL;
        comp.Tail = before;
        return comp;
    }

    curr->previous->next = curr->next;
    curr->next->previous = curr->previous;
    cout << "The Employee " << curr->FirstName << " " << curr->LastName << " with the ID " << curr->UniqueID << " has been deleted!" << endl;
    deleteList(comp, ID); // deletes the Employee present in the appointment's list of attendee
    delete curr;
    return comp;

}

Company insertCalendar(Company comp, int id, string title, int day, int hour, int minute, int second, int duration) { // Inserts a new Calendar for a specific Employee
    Employee* curr, * el;
    Appointment* app, * before;
    Appointment* app1 = new Appointment;
    Attendee* att1 = new Attendee;

    for (el = comp.Head; el != NULL; el = el->next) { // searches in the Company for an id that matches the Employee id
        if (el->UniqueID == id) {
            break;
        }
    }

    app1->Title = title;
    app1->StartingTime.Day = day;
    app1->StartingTime.Hour = hour;
    app1->StartingTime.Minute = minute;
    app1->StartingTime.Second = second;
    app1->Duration = duration;
    app1->next = NULL;
    app1->ListOfAttendees = att1;
    app1->ListOfAttendees->next = NULL;
    app1->ListOfAttendees->self = el;

    for (Employee* empl = comp.Head; empl != NULL; empl = empl->next) {  // To Check if there is a conflict between the inserted meeting and the already existing meetings
        for (Appointment* appo = empl->Calendar; appo != NULL; appo = appo->next) {
            if (appo->StartingTime.Day == day && empl->UniqueID == id) { // if the given day and the given id matches the Employee in the list
                if (appo->StartingTime.Day * 24 * 3600 + appo->StartingTime.Hour * 3600 + appo->StartingTime.Minute * 60 + appo->StartingTime.Second <= day * 24 * 3600 + hour * 3600 + minute * 60 + second <= appo->StartingTime.Day * 24 * 3600 + appo->StartingTime.Hour * 3600 + appo->StartingTime.Minute * 60 + appo->StartingTime.Second + appo->Duration * 60 || appo->StartingTime.Day * 24 * 3600 + appo->StartingTime.Hour * 3600 + appo->StartingTime.Minute * 60 + appo->StartingTime.Second <= day * 24 * 3600 + hour * 3600 + minute * 60 + second + duration * 60 <= appo->StartingTime.Day * 24 * 3600 + appo->StartingTime.Hour * 3600 + appo->StartingTime.Minute * 60 + appo->StartingTime.Second + appo->Duration * 60) {
                    // I converted the time in seconds, then I conditioned that if the new meeting occurs between an already scheduled meeting and that lasts more than the duration of the previous meeting then there is a conflict and it is not possible to create it in that date
                    cout << "A schedule conflict has occured! Please check the calendar of each Employee above before inserting a new meeting" << endl;
                    return comp;
                }
            }


        }
    }

    for (curr = comp.Head; curr != NULL; curr = curr->next) {
        for (app = curr->Calendar, before = NULL; app != NULL; before = app, app = app->next) {} // searches for the last Appointment for a specific Employee to add the new Appointment after it
        if (curr->UniqueID == id) {
            if (before == NULL) { // if the Employee had no organized meeting
                curr->Calendar = app1; // initialize this created meeting as being its new meeting

            }
            else { // if the Employee had already arranged meetings
                before->next = app1; // then add the created meeting as the next meeting of the Employee
            }
        }
    }

    
    return comp;
}

Company cancelMeeting(Company comp, string title, int day, int hour) { // deleting a meeting depending on its title (Single occurence)
    Employee* curr;
    Appointment* app, * before;
    Employee* emp1 = comp.Head;
    for (curr = comp.Head; curr != NULL; curr = curr->next) {
        for (before = NULL, app = curr->Calendar; app != NULL; before = app, app = app->next) {
            if (app->Title == title && app->StartingTime.Day == day && app->StartingTime.Hour == hour) { // if meeting title matches to title given in paramter
                if (before == NULL) { // if the meeting is the first one in the Appointments list
                    curr->Calendar = app->next;
                    delete app;
                    break;
                }
                else {  // if the meeting is anywhere in the list of Appointments
                    before->next = app->next;
                    delete app;
                    break;
                }
            }
        }
    }

    return comp;
}

Company deleteAllMeetings(Company comp, int date) { // Deleting all meetings before a specific day (Single occurence)
    Employee* curr;
    Appointment* app, * before;
    for (curr = comp.Head; curr != NULL; curr = curr->next) {
        for (before = NULL, app = curr->Calendar; app != NULL; before = app, app = app->next) {
            if (app->StartingTime.Day < date) { // if the day of the meeting is before the date of meetings to be deleted
                if (before == NULL) { // if the meeting is the first in the Appointments List
                    curr->Calendar = app->next;
                    delete app;
                    break;
                }
                else {
                    before->next = app->next;
                    delete app;
                    break;
                }
            }
        }
    }

    return comp;
}

Appointment* getminDate(Attendee* At) { // Get the minimum date of the Appointments in the Company
    Appointment* app = new Appointment;
    int min = 365; // setting the minimum day to 365
    for (Attendee* att = At; At != NULL; At = At->next) {
        for (Appointment* a = At->self->Calendar; a != NULL; a = a->next) {
            if (a->StartingTime.Day < min) { // if the appointment day is smaller than the minimum value
                min = a->StartingTime.Day; // the minimum day is now the day found in the appointment
                app = a;
            }
        }
    }
    return app;
}

Appointment* getmaxDate(Attendee* At) { // Get the maximum date of the Appointments in the Company
    Appointment* app = new Appointment;
    int max = 0; // setting the maximum day to 0
    for (Attendee* att = At; att != NULL; att = att->next) {
        for (Appointment* a = att->self->Calendar; a != NULL; a = a->next) {
            if (a->StartingTime.Day > max) {
                max = a->StartingTime.Day;
                app = a;
            }
        }
    }
    return app;

}

void TimeslotsBefore(Attendee* att, int dura) { // Suggestion for any new meeting that can be done before the earliest meeting in the company 
    double res;
    Appointment* app = getminDate(att);
    int day = app->StartingTime.Day; // variable to be incremented showing the limit day for appointments before that day
    int hour = app->StartingTime.Hour; // variable to be incremented showing the limit hour for appointments before that hour
    int min = app->StartingTime.Minute; // variable to be incremented showing the limit minute for appointments before that minute
    int second = app->StartingTime.Second; // variable to be incremented showing the limit second for appointments before that second

    // The below commands are for converting from Hours to minutes
    res = dura;
    if (hour == 0) {
        day = day - 1;
        hour = 24;
    }
    while (dura >= 60) {
        hour = hour - 1;
        dura = dura - 60;
    }
    while (dura > 0) {
        if (min - dura < 0) {
            hour = hour - 1;
            dura = dura - min;
            min = 60;
        }
        else {
            min = min - dura;
            dura = 0;
        }
    }

    cout << "A new meeting can be scheduled before " << day << ":" << hour << ":" << min << ":" << second << endl;

}

void TimeslotsAfter(Attendee* att, int dura) {
    double res;
    Appointment* app = getmaxDate(att);
    int day = app->StartingTime.Day; // variable to be incremented showing the limit day for appointments before that day
    int hour = app->StartingTime.Hour; // variable to be incremented showing the limit hour for appointments before that hour
    int min = app->StartingTime.Minute; // variable to be incremented showing the limit minute for appointments before that minute
    int second = app->StartingTime.Second; // variable to be incremented showing the limit second for appointments before that second
    int durat = app->Duration;

    res = dura;
    if (hour == 24) {
        day = day + 1;
        hour = 0;
    }
    while (durat >= 60) {
        hour = hour + 1;
        durat = durat - 60;
    }
    while (durat > 0) {
        if (min + durat > 60) {
            hour = hour + 1;
            durat = abs(60-(durat + min));
            min = 0;
        }
        else {
            min = min + durat;
            durat = 0;
        }
    }

    cout << "A new meeting can be scheduled after " << day << ":" << hour << ":" << min << ":" << second << endl;

}


Company read(Company comp) // to read the txt file and returns the data of the employees and their schedules
{
    Employee el; // variable of type Employee that takes the inputs of the text file (to be compared with the values of the Linked List)
    Appointment app;
    bool ans = false; // test if the Employee is already present in the list

    ifstream ifs1("input.txt"); // read from txt file name "filename.txt"
    while (ifs1 >> el.UniqueID >> el.FirstName >> el.LastName >> el.EmailAddress >> app.Title >> app.StartingTime.Day >> app.StartingTime.Hour >> app.StartingTime.Minute >> app.StartingTime.Second >> app.Duration) // as long as their is input in the txt file
    {
        ans = false;
        for (Employee* e = comp.Head; e != NULL; e = e->next) {
            for (Appointment* a = e->Calendar; a != NULL; a = a->next) {
                if ((e->FirstName == el.FirstName) && (e->LastName == el.LastName) && (e->UniqueID == el.UniqueID) && (e->EmailAddress == el.EmailAddress) && (a->Title == app.Title) && (a->StartingTime.Day == app.StartingTime.Day) && (a->StartingTime.Hour == app.StartingTime.Hour) && (a->StartingTime.Minute == app.StartingTime.Minute) && (a->StartingTime.Second == app.StartingTime.Second) && (a->Duration = app.Duration)) { // if the values of the linked list employee matches the values in the txt files
                    ans = true; //  no need to insert a new employee in the linked list
                    break;
                }
            }
            
        }
        if (ans == false) { // if the values of the linked list employee does not matche the values in the txt file
            insertSorted(comp, el.UniqueID, el.FirstName, el.LastName, el.EmailAddress, app.Title, app.StartingTime.Day, app.StartingTime.Hour, app.StartingTime.Minute, app.StartingTime.Second, app.Duration); // insert the new employee in a sorted way by the UniqueID

        }

    }
    createList(comp); // create the attendee list based on the Employee's Appointments
    ifs1.close();
    return comp;
}

void write(Company comp) { // write the Company Meetings in the txt file with attendee List
    ofstream myfile("output.txt");
    for (Employee* emp = comp.Head; emp != NULL; emp = emp->next) {
        myfile << "Employee # " << emp->UniqueID << ":" << emp->FirstName << "|" << emp->LastName << "|" << emp->EmailAddress << " Appointments: " << endl;
        myfile << endl;
        for (Appointment* app = emp->Calendar; app != NULL; app = app->next) {
            myfile << "-" << app->Title << "|" << app->StartingTime.Day << "|" << app->StartingTime.Hour << "|" << app->StartingTime.Minute << "|" << app->StartingTime.Second << "|" << app->Duration << "|" << " Attendees:  " << endl;
            myfile << endl;
            for (Attendee* att = app->ListOfAttendees; att != NULL; att = att->next) {
                myfile << "-" << att->self->UniqueID << "|" << att->self->FirstName << "|" << att->self->LastName << "|" << att->self->EmailAddress << endl;
                myfile << endl;
            }
        }
    }
    myfile.close();
}

void writeUpdate(Company comp) { // Write the updated company informations like initial format without attendee List
    ofstream myfile("input.txt", ios::out | ios::trunc);
    for (Employee* emp = comp.Head; emp != NULL; emp = emp->next) {
        if (emp->Calendar == NULL) {}
        else {
            for (Appointment* app = emp->Calendar; app != NULL; app = app->next) {
                myfile << emp->UniqueID << " " << emp->FirstName << " " << emp->LastName << " " << emp->EmailAddress << " ";
                myfile << app->Title << " " << app->StartingTime.Day << " " << app->StartingTime.Hour << " " << app->StartingTime.Minute << " " << app->StartingTime.Second << " " << app->Duration << endl;
            }
        }
    }
    myfile.close();
}

int main() {
    Employee* emp1 = new Employee;
    Appointment* app1 = new Appointment;
    Attendee* att1 = new Attendee;
    Employee elread;
    Appointment appread;
    Company comp;

    comp.Head = emp1;
    comp.Tail = emp1;

    // Insert the first Employee in the list as the first Employee in the company and initializing it
    ifstream ifs("input.txt");
    ifs >> elread.UniqueID >> elread.FirstName >> elread.LastName >> elread.EmailAddress >> appread.Title >> appread.StartingTime.Day >> appread.StartingTime.Hour >> appread.StartingTime.Minute >> appread.StartingTime.Second >> appread.Duration;
    emp1->FirstName = elread.FirstName;
    emp1->LastName = elread.LastName;
    emp1->UniqueID = elread.UniqueID;
    emp1->EmailAddress = elread.EmailAddress;

    app1->next = NULL;
    emp1->Calendar = app1;
    emp1->Calendar->Title = appread.Title;
    emp1->Calendar->StartingTime.Day = appread.StartingTime.Day;
    emp1->Calendar->StartingTime.Hour = appread.StartingTime.Hour;
    emp1->Calendar->StartingTime.Minute = appread.StartingTime.Minute;
    emp1->Calendar->StartingTime.Second = appread.StartingTime.Second;
    emp1->Calendar->Duration = appread.Duration;

    emp1->Calendar->ListOfAttendees = att1;
    emp1->Calendar->ListOfAttendees->self = emp1;
    emp1->Calendar->ListOfAttendees->next = NULL;

    emp1->next = NULL;
    emp1->previous = NULL;
    emp1->Calendar->next = NULL;
    ifs.close();
    id++;
    read(comp);

    for (Employee* e = comp.Head; e != NULL; e = e->next) {
        comp.Tail = e;
    }     // updating the company Tail

    displayCompany(comp);

    cout << "Hello Dear User!" << endl;
    cout << "Please choose one of the options below by entering the choosen number: " << endl;
    cout << "1-Search for a particular Employee in the company" << endl;
    cout << "2-Add a new Employee to the company" << endl;
    cout << "3-Delete an Employee from the Company" << endl;
    cout << "4-Add a new meeting to particular Employees" << endl;
    cout << "5-Cancel an already scheduled meeting " << endl;
    cout << "6-Cancel all the scheduled meetings before a given day " << endl;
    cout << "7-Propose a timeslot where Particular Employees are free for a meeting" << endl;
    cout << "8-Write the updated list of Employees in the company in the 'output.txt' file" << endl;
    cout << "9-Exit" << endl << endl;
    int nb;
    cin >> nb;

    while (nb != 1 || nb != 2 || nb != 3 || nb != 4 || nb != 5 || nb != 6 || nb != 7 || nb != 8 || nb != 9) {
        if (nb == 1) {
            Employee* e1;
            int id1;
            string fname1, lname1, email1;
            cout << "Enter the ID of the Employee: ";
            cin >> id1;
            cout << "Enter the first name of the Employee: ";
            cin >> fname1;
            cout << "Enter the last name of the Employee: ";
            cin >> lname1;
            cout << "Finally Enter the email address of the Employee: ";
            cin >> email1;
            e1 = FindEmployee(comp, id1, fname1, lname1, email1); // search for employee with equal arguments' value
            if (e1 != NULL) {
                cout << endl << "The given informations match an Employee in the company! Here are the results: " << endl << endl;
                printEmpInfo(comp, id1, fname1, lname1, email1);
            }
            else
                cout << endl << "No Employee with the entered credentials found in this company" << endl << endl;
        }
        else if (nb == 2) {
            string fname2, lname2, email2;
            cout << "Enter the first name of the new Employee: ";
            cin >> fname2;
            cout << "Enter the last name of the new Employee: ";
            cin >> lname2;
            cout << "Enter the email address of the new Employee: " << endl;
            cin >> email2;
            insertEmployee(comp, ++id, fname2, lname2, email2); // add a new Employee to the Company
            for (Employee* e = comp.Head; e != NULL; e = e->next) {
                comp.Tail = e; // update tail since Employee is inserted at the end of the company
            }
            cout << endl << "Here is the updated list of Employees:" << endl;
            cout << endl;
            displayCompany(comp);
        }
        else if (nb == 3) {
            int id3;
            cout << "Enter the Employee's Unique ID that you want to delete:  ";
            cin >> id3;
            while (!FindbyID(comp, id3)) { // if the id doesn't match an employee in the company
                cout << "No such ID matches the table! Please refer to the above table and re-enter the correct Id: ";
                cin >> id3;
            }
            comp = deleteEmployee(comp, id3);

            cout << endl << "Here is the updated list of Employees:" << endl;
            cout << endl;
            displayCompany(comp);

        }
        else if (nb == 4) {
            char choice4 = 'y';
            int id4, day4, hour4, minute4, second4, duration4;
            
            string title4;
            cout << "Enter the title of the new appointment: ";
            cin >> title4;
            cout << "Enter the day at which the appointment starts (Number between 1 and 365) : ";
            cin >> day4;
            while (1 > day4 || day4 > 365) {
                cout << "Please stick to format (Number between 1 and 365): ";
                cin >> day4;
            }
            cout << "Enter the hour at which the appointment starts (Number betwwen 0 and 23) : ";
            cin >> hour4;
            while (0 > hour4 || hour4 > 23) {
                cout << "Please stick to format (Number between 0 and 23): ";
                cin >> hour4;
            }
            cout << "Enter the minute at which the appointment starts (Number between 0 and 59) : ";
            cin >> minute4;
            while (0 > minute4 || minute4 > 59) {
                cout << "Please stick to format (Number between 0 and 59): ";
                cin >> minute4;
            }
            cout << "Enter the second at which the appointment starts (Number between 0 and 59) : ";
            cin >> second4;
            while (0 > second4 || second4 > 59) {
                cout << "Please stick to format (Number between 0 and 59): ";
                cin >> second4;
            }
            cout << "Enter the duration of the appointment in minutes: ";
            cin >> duration4;

            while (choice4 == 'y') {
                cout << "Enter the id of the Employee that you want to insert the appointment to:";
                cin >> id4;
                while (!FindbyID(comp, id4)) {
                    cout << "No such ID matches the table! Please refer to the above table and re-enter the correct Id: ";
                    cin >> id4;
                }
                comp = insertCalendar(comp, id4, title4, day4, hour4, minute4, second4, duration4);
                

                cout << "Would you like to add this appointment to another Employee? Please Respond by 'y' for yes and 'n' for no : ";
                cin >> choice4;
                while (choice4 != 'y' && choice4 != 'n') {
                    cout << "Please enter either 'y' for yes or 'n' for no: ";
                    cin >> choice4;
                }
            }
            Attendee* acurr;
            for (Employee* e1 = comp.Head; e1 != NULL; e1 = e1->next) {
                for (Appointment* a1 = e1->Calendar; a1 != NULL; a1 = a1->next) {
                    for (acurr = a1->ListOfAttendees; acurr->next != NULL; acurr = acurr->next) {} // searches for the last Employee in the Attendee List
                    if ( (a1->Title == title4) && (a1->StartingTime.Day == day4) && (a1->StartingTime.Hour == hour4))
                        FindTitleAttendee(comp, a1->ListOfAttendees->self->UniqueID, title4, day4, hour4, minute4, second4, duration4, acurr);
                }
            }
            cout << endl << "The updated list of Employee looks like this: " << endl;
            cout << endl;
            displayCompany(comp);
        }
        else if (nb == 5) {
            string title5;
            int day5, hour5;
            cout << "Enter the title of the meeting you want to cancel: ";
            cin >> title5;
            cout << "Enter the day of that meeting (Number between 1 and 365) : ";
            cin >> day5;
            while (1 > day5 || day5 > 365) {
                cout << "Please stick to format (Number between 1 and 365): ";
                cin >> day5;
            }
            cout << "Enter the hour at which the appointment starts (Number betwwen 0 and 23) : ";
            cin >> hour5;
            while (0 > hour5 || hour5 > 23) {
                cout << "Please stick to format (Number between 0 and 23): ";
                cin >> hour5;
            }

            comp = cancelMeeting(comp, title5, day5, hour5);

            cout << endl << "The updated list of Employee looks like this: " << endl;
            cout << endl;
            displayCompany(comp);

        }
        else if (nb == 6) {
            int day6;
            cout << "Enter the day where all the meetings scheduled before that day will be canceled (Number between 1 and 365) : ";
            cin >> day6;
            while (1 > day6 || day6 > 365) {
                cout << "Please stick to format (Number between 1 and 365): ";
                cin >> day6;
            }
            while (FindCalendarDay(comp, day6)) { // find all the days before the day in parameter where there is a meeting
                comp = deleteAllMeetings(comp, day6);
            }
            cout << "The updated list of Employees looks like this: " << endl;
            cout << endl;
            displayCompany(comp);
        }
        else if (nb == 7) {
            char choice7 = 'y';
            int id71, id72, id7o; // id71 and id72 for the two first attendees id and id7o stands for id optinal if one employee is added to the  attendee list
            int duration = 0;
            Employee* e;
            Attendee* list71 = new Attendee; // creating a new attendee list
            Attendee* at;
            cout << "Enter the id of the first Employee that you want to insert a potential new meeting to: ";
            cin >> id71;
            while (!FindbyID(comp, id71)) {
                cout << "No such ID matches the table! Please refer to the above table and re-enter the correct Id: ";
                cin >> id71;
            }
            list71->self = FindbyID(comp, id71);
            cout << "Enter the id of the second Employee that you want to insert a potential new meeting to: ";
            cin >> id72;
            Attendee* list72 = new Attendee;
            while (!FindbyID(comp, id72)) {
                cout << "No such ID matches the table! Please refer to the above table and re-enter the correct Id: ";
                cin >> id72;
            }
            list72->self = FindbyID(comp, id72);
            list71->next = list72;
            list72->next = NULL;

            while (choice7 == 'y') {
                cout << "Would you like to enter another attendee to this list? Please Respond by 'y' for yes and 'n' for no : ";
                cin >> choice7;
                while (choice7 != 'y' && choice7 != 'n') {
                    cout << "Please enter either 'y' for yes or 'n' for no: ";
                    cin >> choice7;
                }
                if (choice7 == 'n')
                    break;
                cout << "Enter the id of the other Employee that you want to insert a potential new meeting to: ";
                cin >> id7o;
                while (!FindbyID(comp, id7o)) {
                    cout << "No such ID matches the table! Please refer to the above table and re-enter the correct Id: ";
                    cin >> id7o;
                }
                Attendee* list7o = new Attendee;
                list7o->self = FindbyID(comp, id7o);
                list7o->next = NULL;
                for (at = list71; at->next != NULL; at = at->next) {}
                at->next = list7o;
            }
            cout << "Enter the minimum duration of the new meeting in minutes" << endl;
            cin >> duration;
            cout << endl;
            TimeslotsBefore(list71, duration); // suggest a timeslot before the first meeting in the calendar
            TimeslotsAfter(list71, duration); // suggest a timeslot after the last meeting in the calendar
            cout << endl;

        }
        else if (nb == 8) {
            write(comp);
            cout << endl << "'output.txt' file created successfully!" << endl;
            writeUpdate(comp);
            cout << "'input.txt' file has been updated to initially similar format " << endl;
        }
        else if (nb == 9) {
            cout << endl << "Thank you for using our program!" << endl;
            break;
        }
        cout << endl << "If you would like to use our program again Enter the correct number again: " << endl;
        cout << "Hello Dear User!" << endl;
        cout << "Please choose one of the options below by entering the choosen number: " << endl;
        cout << "1-Search for a particular Employee in the company" << endl;
        cout << "2-Add a new Employee to the company" << endl;
        cout << "3-Delete an Employee from the Company" << endl;
        cout << "4-Add a new meeting to particular Employees" << endl;
        cout << "5-Cancel an already scheduled meeting " << endl;
        cout << "6-Cancel all the scheduled meetings before a given day " << endl;
        cout << "7-Propose a timeslot where Particular Employees are free for a meeting" << endl;
        cout << "8-Write the updated list of Employees in the company in the 'output.txt' file" << endl;
        cout << "9-Exit" << endl;
        cout << endl;
        cin >> nb;
    }


    return 0;
}